# CALDERA plugin: Emu

A plugin supplying CALDERA with TTPs from the Center for Threat Informed Defense Adversary Emulation Plans.

Each emulation plan will have an advesary and a set of facts. Please ensure to select the related facts to the advesary when starting an operation.

## Acknowledgements

- [Adversary Emulation Library](https://github.com/center-for-threat-informed-defense/adversary_emulation_library)
