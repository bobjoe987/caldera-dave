# Access

Plugin supplying CALDERA with red-team tools and functions, as applied to initial access.
