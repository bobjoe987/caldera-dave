# 54ndc47

A plugin supplying a default agent to be used in a CALDERA operation.

[Read the full docs](https://github.com/mitre/caldera/wiki/Plugins-sandcat)
