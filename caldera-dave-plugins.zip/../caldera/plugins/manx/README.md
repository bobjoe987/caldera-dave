# CALDERA Plugin: Manx

The Manx plugin supplies shell access into CALDERA, along with reverse-shell payloads for entering/exiting agents manually. 
