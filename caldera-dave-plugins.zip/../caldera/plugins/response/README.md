# Response

A plugin for doing autonomous incident response