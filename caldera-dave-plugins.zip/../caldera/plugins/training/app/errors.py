class ObjectDoesNotExist(Exception):
    pass


class BadgeDoesNotExist(ObjectDoesNotExist):
    pass


class FlagDoesNotExist(ObjectDoesNotExist):
    pass
