1. Open the Navigate menu.
1. Select `Campaigns > agents`.
1. In the left side of the window, click on `IMPLANT NAME`
1. Enter `super_scary` into the text box
1. Press the `Save` button
1. Task completed