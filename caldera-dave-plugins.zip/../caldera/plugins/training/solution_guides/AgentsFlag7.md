1. Open the Navigate menu.
1. Select `Campaigns > agents`.
1. In the agents table, click on the PID button for a row (opens a window).
1. Press the `Kill agent` button
1. Task completed.