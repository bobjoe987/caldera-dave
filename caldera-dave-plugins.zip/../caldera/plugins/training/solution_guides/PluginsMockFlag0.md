1. Open the Navigate menu.
1. Select `Advanced > configuration`.
1. Under Plugins, press the enable button on the mock plugin row.
1. Terminate the CALDERA server.
1. Re-run the server. Ensure the `--fresh` flag is not used.
1. Open the Navigate menu.
1. Select `Campaigns > operations`.
1. Press the View/Add switch to open the operation creation menu.
1. Give the operation a name.
1. Press Basic Options to open the basic options list.
1. Select the "simulation" group from the agent group dropdown.
1. Select the "Hunter" adversary from the adversary dropdown.
1. Select "Auto close operation" from the keep open or close dropdown.
1. Press Start to run the operation.
1. Wait for the operation to complete.
1. If the "Auto close operation" option was not selected, press the stop button to finish the operation.
1. Task completed.
