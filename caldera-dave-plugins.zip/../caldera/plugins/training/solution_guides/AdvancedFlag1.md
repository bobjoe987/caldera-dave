1. Open the Navigate menu.
1. Select `Advanced > fact sources`.
1. Press the View/Add switch to open the fact source creation menu.
1. Replace "Sample name" with "better basic".
1. Press the "+ add fact" text button.
1. Enter a trait (ex: "host.file.path").
1. Enter a value (ex: "C:\Windows\System32\calc.exe").
1. Press the "View rules" button.
1. Press the "+ add rule" text button.
1. Enter a trait (ex: "host.file.path").
1. Enter a match value (ex: "C:\Windows\System32\calc.exe").
1. Enter "ALLOW" for the action.
1. Exit the rules dialog.
1. Press the Save button.
1. Task completed.
