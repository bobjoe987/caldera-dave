1. Open the Navigate menu.
1. Select `Advanced > configuration`.
1. Change the `app.contact.http` value to a URL with and externally-facing IP address (not http://127.0.0.1:8888)
1. Press the update button in the `app.contact.http` row.
1. Task completed.
