1. Open the Navigate menu.
1. Select `Campaigns > agents`.
1. On the left side of the window, click on `UNTRUSTED TIMER`
1. Enter 60 into the text box.
1. Press the Save button.
1. Task completed