1. Open the Navigate menu.
1. Select `Campaigns > adversaries`.
1. In the _Adversary Profiles_ window that opens, ensure that the toggle button says `View`.
1. In the drop-down, select the `Certifiable` adversary profile.
1. Press the `+ add adversary` button on the right side of the window.
1. In the window that appears, select the `Nosy Neighbor` item from the drop-down and press `Add to Adversary`.
1. On the left side of the window, press the `Save` button.
1. Task completed.