1. Open the Navigate menu.
1. Select `Campaigns > agents`.
1. In the agents table, click on the PID button for a row (opens a window).
1. In the `Sleep` row, click on the `30/60` value in the right column (text will become editable)
1. Enter a different `min/max` value (e.g., `50/100`)
1. Press the `Save` button
1. Task completed