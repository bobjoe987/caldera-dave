# CALDERA Plugin: Mock

The mock plugin adds simulated agents to CALDERA, which can be used in normal operations. These 
simulated agents use mock responses, which can be added for any ability.
