__version__ = '3.1.0'


def get_version():
    return __version__
